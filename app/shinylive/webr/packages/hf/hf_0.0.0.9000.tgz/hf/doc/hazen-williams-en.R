## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(hf)

## ----head_loss----------------------------------------------------------------
library(hf)
calc_head_loss_hw(length = 150, flow = 0.025, diameter = 0.1, coef = 150)

## ----diameter-----------------------------------------------------------------
library(hf)
calc_diameter_hw(loss = 5, length = 150, flow = 0.025, coef = 150)

## ----flow---------------------------------------------------------------------
library(hf)
calc_flow_hw(loss = 3, length = 100, diameter = 0.15, coef = 140)

