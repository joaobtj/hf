## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(hf)

## ----friction_factors---------------------------------------------------------
# Flow parameters
Re <- 100000        # Reynolds number
e <- 0.00026        # Absolute roughness (m)
D <- 0.1            # Diameter (m)

# Compare both methods
calc_friction_cw(reynolds = Re, roughness = e, diameter = D)
calc_friction_sj(reynolds = Re, roughness = e, diameter = D)

## ----head_loss----------------------------------------------------------------
# 1. Default approach (Uses Colebrook-White automatically)
calc_head_loss_darcy(
  length = 100, flow = 0.02, diameter = 0.1, roughness = 0.00026
)

# 2. Functional Injection (Using Swamee-Jain)
calc_head_loss_darcy(
  length = 100, flow = 0.02, diameter = 0.1, roughness = 0.00026,
  friction_fun = calc_friction_sj
)

# 3. Direct Value (If you already know the friction factor)
calc_head_loss_darcy(
  length = 100, flow = 0.02, diameter = 0.1, friction_factor = 0.025
)

## ----iterative_solvers--------------------------------------------------------
# Calculate the required diameter for a target head loss of 8.56m
calc_diameter_darcy(
  loss = 8.56, length = 100, flow = 0.02, roughness = 0.00026
)

# Calculate the maximum flow rate for the same head loss
calc_flow_darcy(
  loss = 8.56, length = 100, diameter = 0.1, roughness = 0.00026
)

