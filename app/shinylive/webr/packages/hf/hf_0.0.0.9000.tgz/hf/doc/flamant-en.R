## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(hf)

## ----head_loss----------------------------------------------------------------
library(hf)
calc_head_loss_flamant(length = 50, flow = 0.0002, diameter = 0.015)

## ----diameter-----------------------------------------------------------------
library(hf)
calc_diameter_flamant(loss = 1.5, length = 50, flow = 0.0002)

## ----flow---------------------------------------------------------------------
library(hf)
calc_flow_flamant(loss = 1.5, length = 50, diameter = 0.015)

