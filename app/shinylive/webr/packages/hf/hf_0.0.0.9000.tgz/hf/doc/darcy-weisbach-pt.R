## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

library(hf)

## ----fator_atrito-------------------------------------------------------------
# Parâmetros do escoamento
Re <- 100000        # Número de Reynolds
e <- 0.00026        # Rugosidade absoluta (m)
D <- 0.1            # Diâmetro (m)

# Comparando ambos os métodos
calc_friction_cw(reynolds = Re, roughness = e, diameter = D)
calc_friction_sj(reynolds = Re, roughness = e, diameter = D)

## ----perda_carga--------------------------------------------------------------
# 1. Padrão (Usa Colebrook-White automaticamente)
calc_head_loss_darcy(
  length = 100, flow = 0.02, diameter = 0.1, roughness = 0.00026
)

# 2. Injeção Funcional (Usando Swamee-Jain)
calc_head_loss_darcy(
  length = 100, flow = 0.02, diameter = 0.1, roughness = 0.00026,
  friction_fun = calc_friction_sj
)

# 3. Valor Direto (Se você já calculou o fator de atrito)
calc_head_loss_darcy(
  length = 100, flow = 0.02, diameter = 0.1, friction_factor = 0.025
)

## ----solucionadores-----------------------------------------------------------
# Calcular o diâmetro necessário para uma perda de 8.56m
calc_diameter_darcy(
  loss = 8.56, length = 100, flow = 0.02, roughness = 0.00026
)

# Calcular a vazão máxima para a mesma perda de carga
calc_flow_darcy(
  loss = 8.56, length = 100, diameter = 0.1, roughness = 0.00026
)

